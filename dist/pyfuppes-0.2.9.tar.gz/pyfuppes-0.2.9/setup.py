# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes', 'pyfuppes.utils']

package_data = \
{'': ['*']}

install_requires = \
['geopy>=2.0,<3.0',
 'matplotlib>=3.0,<4.0',
 'numba>=0.56.4,<0.57.0',
 'numpy>=1.23.5,<2.0.0',
 'pandas>=1.0,<2.0',
 'polars>=0.15,<0.16',
 'pyarrow>=10.0,<11.0',
 'pysolar>=0.10,<0.11',
 'scipy>=1.1,<2.0',
 'xarray>=2022']

extras_require = \
{':python_version > "3.9"': ['llvmlite>=0.39.1,<0.40.0']}

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.2.9',
    'description': 'A collection of tools in Python',
    'long_description': "# pyfuppes\nA collection of tools in Python.\n* Free software: MIT license\n\n\n## Installation\n\nfrom `wheel` file:\n* check `/dist` directory for a wheel file\n* *or* (fork and) clone the repo, then run `poetry build` in the repo's directory to create one for the latest version\n\neditable via `pip`:\n* (fork and) clone the repo, then `pip install -e .`\n\n\n## Requirements\n\n* see [pyproject.toml](https://github.com/FObersteiner/pyFuppes/blob/master/pyproject.toml)\n\n\n## Content\n\nSee https://pyfuppes.readthedocs.io/en/latest/ or directly go to [API reference](https://pyfuppes.readthedocs.io/en/latest/autoapi/index.html).\n",
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
