# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes', 'pyfuppes.na1001_helpers']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.1.4',
    'description': "MrFuppes' collection of Python tools",
    'long_description': None,
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<3.9',
}


setup(**setup_kwargs)
