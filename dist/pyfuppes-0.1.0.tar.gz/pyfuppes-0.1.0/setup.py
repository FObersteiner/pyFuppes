# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes', 'pyfuppes.na1001_helpers']

package_data = \
{'': ['*']}

install_requires = \
['geopy>=2.0.0,<3.0.0',
 'matplotlib>=3.3.2,<4.0.0',
 'numba>=0.51.2,<0.52.0',
 'numpy>=1.19.2,<2.0.0',
 'pandas>=1.1.2,<2.0.0',
 'pysolar>=0.8,<0.9',
 'scipy>=1.5.2,<2.0.0']

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.1.0',
    'description': "MrFuppes' collection of Python tools",
    'long_description': None,
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
