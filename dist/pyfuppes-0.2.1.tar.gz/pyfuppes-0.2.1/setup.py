# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes', 'pyfuppes.utils']

package_data = \
{'': ['*']}

install_requires = \
['geopy>=2.2.0,<3.0.0',
 'matplotlib>=3.5.1,<4.0.0',
 'numba>=0.55.1,<0.56.0',
 'numpy>=1.22.0,<2.0.0',
 'pandas>=1.4.1,<2.0.0',
 'pysolar>=0.10,<0.11',
 'scipy>=1.8.0,<2.0.0',
 'xarray>=2022.3.0,<2023.0.0']

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.2.1',
    'description': 'A collection of Python tools',
    'long_description': None,
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
