# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.2.0',
    'description': 'A collection of Python tools',
    'long_description': None,
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<3.10',
}


setup(**setup_kwargs)
