# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyfuppes', 'pyfuppes.utils']

package_data = \
{'': ['*']}

install_requires = \
['geopy>=2.0.0,<3.0.0',
 'matplotlib>=3.0.0,<4.0.0',
 'numba>=0.56.0,<0.57.0',
 'numpy>=1.0.0,<2.0.0',
 'pandas>=1.0.0,<2.0.0',
 'pysolar',
 'scipy>=1.0.0,<2.0.0',
 'xarray>=2022.0.0,<2023.0.0']

setup_kwargs = {
    'name': 'pyfuppes',
    'version': '0.2.7',
    'description': 'A collection of tools in Python',
    'long_description': 'None',
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@kit.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
